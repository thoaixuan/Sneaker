<?php
/**
 * template name: Landing Page Layout Example
 */
wp_reset_query();
/*get_template_part('landing-pages/inc/header');
get_template_part('landing-pages/inc/custom-menu');*/
?>

Code here



