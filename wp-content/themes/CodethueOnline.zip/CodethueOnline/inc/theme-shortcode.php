<?php
/*Exam ShortCode
function make_beautiful_tag($args, $content) {
        return '<div class="make_beautiful_tag"><div class="make_beautiful_tag_child">' . do_shortcode($content) . '</div></div>';  
    }
add_shortcode( 'khung-dep', 'make_beautiful_tag' );
*/
?>