<section class="features pd-top-bot-20">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-12 mb-4">
                <div class="icon__box">
                    <div class="icon__box__header">
                        <div class="icon"><i class="fas fa-wallet"></i></div>
						  <h3>Cam Kết chính hãng</h3>
						  <p>100 % Authentic</p>
                    </div>
                    <div class="icon__box__header">Content</div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-12 mb-4">
                <div class="icon__box">
                    <div class="icon__box__header">
                        <div class="icon"><i class="fas fa-truck"></i></div>
						  <h3>Cam Kết chính hãng</h3>
						  <p>100 % Authentic</p>
                    </div>
                    <div class="icon__box__header">Content</div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-12 mb-4">
                <div class="icon__box">
                    <div class="icon__box__header">
                        <div class="icon"><i class="fab fa-servicestack"></i></div>
						  <h3>Cam Kết chính hãng</h3>
						  <p>100 % Authentic</p>
                    </div>
                    <div class="icon__box__header">Content</div>
                </div>
            </div>
        </div>
    </div>
</section>