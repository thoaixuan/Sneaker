<section class="ct-product">
    <div class="container">
        <div class="ct-title pos-rel" data-mask="Product">
           <h3 class="ct-tile-product"> - sản phẩm mới</h3>
        </div>
        <!--Show product-->
        <div class="row-codethue">
            <div class="col-codethue-12">
                <?=do_shortcode("[show_product][/show_product]")?>
                <!--pag product-->
                
            </div>
        </div>
    </div>
</section>