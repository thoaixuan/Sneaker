<section class="ct__subscribe">
<div class="container">
    <div class="row-codethue">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <h3 class="text--light text-uppercase"><i class="fa fa-envelope"></i> đăng ký nhận code</h3>
        </div>
        <div class="col-lg-5 col-md-6 col-sm-6 col-xs-12 ">
            <div class="ct__form_sub text-center">
                <form class="ct-subscribe__form pos-rel" action="" method="POST">
                    <input type="text" placeholder="Nhập email để nhận tin" class="input pos-rel">
                    <button type="submit" class="btn pos-ab">ĐĂNG KÝ</button>
                </form>
            </div>
        </div>
        <div class="col-lg-4 col-md-3 col-sm-12 col-xs-12 ">
            <p class="text--light font-size-14">...Nhận Ngay<span> VOUCHER 100k </span>từ chúng tôi.</p>
        </div>
    </div>
</div>
</section>