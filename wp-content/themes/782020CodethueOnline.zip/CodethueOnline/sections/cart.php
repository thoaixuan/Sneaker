<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="exampleModalLongTitle">Giỏ hàng</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row-codethue">
              <div class="d-inline cart-codethue">
                  <div class="col-lg-3 padding-left-u text-center">
                  <img src="urlimg" id="url_img_pro" class="pos-rel" alt="">
                  </div>     
                  <div class="col-lg-9 padding__left--15 ct-shoes-content">
                    <a class="ct-shoes-name d--block text-up hover--primary__Color" id="name-product-cart">Example Name</a>
                  <div id="sl-cart">Example SL</div>
                  <div id="size-cart">Example SIZE</div>    
                  <div id="price-cart" class="price-product">Example VNĐ</div>
                  </div>
              </div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
        <button type="button" class="btn btn-primary">Thanh toán</button>
      </div>
    </div>
  </div>
</div>