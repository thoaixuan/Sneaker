/*Thoai_Hacker >> CART Js*/
checkCookie('name_product');

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
}

function delete_cookie(cname) { document.cookie = cname + "=" + "; " + 0; }
function checkCookie(cname) {
    var cname=getCookie("name_product");
    if (cname!="") {
        document.getElementById("name-product-cart").innerHTML = getCookie('name_product');
        document.getElementById("sl-cart").innerHTML = 'Số lượng: '+getCookie('sl_product');
        document.getElementById("size-cart").innerHTML = 'Size: '+ getCookie('size_product');
        document.getElementById("price-cart").innerHTML ='Giá: '+ getCookie('prize');

        document.getElementById("url_img_pro").src = getCookie('url_img_product');
        document.getElementById("name-product-cart").href  =getCookie('url_product');
        /*setCookie('url_product',url_product , 1);*/
       
    } else {
        document.getElementById("name-product-cart").innerHTML = '';
        document.getElementById("sl-cart").innerHTML = '';
        document.getElementById("size-cart").innerHTML = '';
        document.getElementById("price-cart").innerHTML = '';
        /**/
        alert("Giỏ hàng trống");
    }
}

function listCookies() {
    var theCookies = document.cookie.split(';');
    var aString = '';
    for (var i = 1 ; i <= theCookies.length; i++) {
        aString += i + ' ' + theCookies[i-1] + "\n";
    }
    return aString;
}
var clicks = 0;
function add_to_cart(){
  /*Block spam click */
  clicks += 1;
  if(clicks==4){alert("Do not CLICK SPAM  ! I'm Hacker"); window.location.href ='https://www.youtube.com/watch?v=m2dz_z-3B0s';}
  /*----------------- */
  var name_product, size_product, sl_product, prize;

  checkCookie(name_product);
  name_product = document.getElementById("name_product").value;
  size_product = document.getElementById("size_product").value;
  sl_product = document.getElementById("1").value;
  prize = document.getElementById("prize").value;
  url_product = document.getElementById("link_product").value;
  url_img_product = document.getElementById("img_product").value;
  /*Delete cooki: setCookie('username','giatricookie' , 1); hoac delete_cookie('username');*/
  setCookie('name_product',name_product , 1);
  setCookie('size_product',size_product , 1);
  setCookie('sl_product',sl_product , 1);
  setCookie('prize',prize , 1);
  setCookie('url_product',url_product , 1);
  setCookie('url_img_product',url_img_product , 1);
  /*var y = getCookie('prize');
  console.log(getCookie('name_product'),'>> Size : '+getCookie('size_product'),
  '>>SL : '+ getCookie('sl_product'),'>>Gia : '+getCookie('prize')
  ,'>>Link product : '+getCookie('url_product'),'>>IMG LINK : '+getCookie('url_img_product'));*/
  alert("Đã thêm vào giỏ hàng");
  location.reload(); 
}